import requests
from config import config


class ApiLogin:
    def __init__(self):
        self.login_url = config.BASE_URL + '/ssm_web/user/login'

    def login(self, params):
        return requests.post(url=self.login_url, params=params)


if __name__ == '__main__':
    print("hi")
    api = ApiLogin()
    response = api.login({"phone": "15321919666", "password": "123456"})
    print(response.status_code)
    print(response.text)
