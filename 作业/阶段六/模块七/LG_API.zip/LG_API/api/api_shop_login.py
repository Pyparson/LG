import requests
from config.config import BASE_SHOP_URL

class LgShopLogin:
    def __init__(self):
        self.verify_url = BASE_SHOP_URL + "/index.php?m=Home&c=User&a=verify"
        self.login_url = BASE_SHOP_URL + "/index.php?m=Home&c=User&a=do_login"

    def get_verify_session(self,session):
        return session.get(self.verify_url)

    def login(self,session,username,password,verify_code,headers):
        data = f"username={username}&password={password}&verify_code={verify_code}"

        return session.post(url=self.login_url,
                            data=data,
                            headers=headers)

if __name__ == '__main__':
    session = requests.Session()
    lgshop = LgShopLogin()
    response = lgshop.get_verify_session(session)
    print(response.content)
    headers = {"Content-Type": "application/x-www-form-urlencoded"}
    response = lgshop.login(session,'13800138006','123456','8889',headers)
    print(response.json())
