import requests
from config.config import BASE_SHOP_URL
from tool.md5_encode import lg_md5_encode


class LgShopRegister:

    def __init__(self):
        self.verify_url = BASE_SHOP_URL + "/index.php?m=Home&c=User&a=verify&type=user_reg"
        self.register_url = BASE_SHOP_URL + "/index.php/Home/User/reg.html"

    def get_verify_session(self,session):
        return session.get(url=self.verify_url)

    def register(self,session,phone,verify_code,password,password1,headers):
        pw = lg_md5_encode(password)
        pw1 = lg_md5_encode(password1)
        data = f"auth_code=TPSHOP&scene=1&username={phone}&verify_code={verify_code}&password={pw}&password2={pw1}"
        return session.post(url=self.register_url,
                            data=data,
                            headers=headers)

if __name__ == '__main__':
    session = requests.Session()
    lgshop = LgShopRegister()
    response = lgshop.get_verify_session(session)
    print(response.content)
    headers = {"Content-Type": "application/x-www-form-urlencoded"}
    response1 = lgshop.register(session,'13800138006','8889','123456','123456',headers)
    print(response1.json())
