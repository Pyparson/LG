import os

BASE_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__),  ".."))
BASE_URL = 'http://www.edu2.com:8090'
BASE_SHOP_URL = 'http://192.168.10.39'
