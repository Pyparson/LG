# 导包
import os
import unittest
from threadpool import ThreadPool,makeRequests

import lib.HTMLTestRunner_PY3
from testcase.test_login import TestLogin

# 多线程执行用例
def get_testcases(testcases):
    tl = unittest.TestLoader()
    suite = tl.loadTestsFromTestCase(testcases)
    print(suite)
    return suite

def run_testcases(suite):
    runner = unittest.TextTestRunner()
    result = runner.run(suite)
    return result

# 多线程执行用例
def main2():
    suite = get_testcases(TestLogin)
    pool = ThreadPool(10)
    requests = makeRequests(run_testcases,suite)
    for req in requests:
        pool.putRequest(req)
    pool.wait()


if __name__ == '__main__':
    base_path = os.path.dirname(__file__)
    p = os.path.abspath(os.path.join(base_path,  "report", "report.html"))
    # 创建测试套件
    suite = unittest.TestSuite()
    # 将测试用例添加到测试套件
    suite.addTests(unittest.makeSuite(TestLogin))
    # 使用HTMLTestRunner运行测试用例，生成测试报告
    with open(p, 'wb') as f: # 打开要生成的测试报告文件
        # 实例化runner
        runner = lib.HTMLTestRunner_PY3.HTMLTestRunner(f)
        # 使用runner运行测试套件，得到测试结果
        result = runner.run(suite)
        # 使用runner生成测试报告
        runner.generateReport(suite, result)