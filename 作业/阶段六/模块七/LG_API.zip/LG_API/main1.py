# 导包
import os
import unittest

from threadpool import makeRequests,ThreadPool

from testcase.test_login import TestLogin
import lib.HTMLTestRunner_PY3
import threading

base_path = os.path.dirname(__file__)
p = os.path.abspath(os.path.join(base_path, "report", "report1.html"))

def get_suite(suite):
    t1 = unittest.TestLoader()
    suite = t1.loadTestsFromTestCase(TestLogin)
    with open(p,'wb') as f:
        runner = lib.HTMLTestRunner_PY3.HTMLTestRunner(f)
        result =  runner.run(suite)
        runner.generateReport(suite, result)

def get_testcases(testcases):
    t1 = unittest.TestLoader()
    suite = t1.loadTestsFromTestCase(testcases)
    return suite

def run_testcases(suite):
    with open(p,'wb') as f:
        runner = lib.HTMLTestRunner_PY3.HTMLTestRunner(f)
        result =  runner.run(suite)
        runner.generateReport(suite, result)

def main2():
    suite=get_testcases(TestLogin)
    pool = ThreadPool(5)
    requests = makeRequests(run_testcases,suite)
    for req in requests:
        pool.putRequest(req)
    pool.wait()

if __name__ == '__main__':
    # 多线程执行测试用例
    # threads = []
    # for i in range(5):
    #     t = threading.Thread(target=get_suite,args=(i,))
    #     threads.append(t)
    # for i in threads:
    #     i.start()
    main2()