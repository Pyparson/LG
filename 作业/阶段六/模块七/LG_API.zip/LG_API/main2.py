# 多线程执行测试用例
import unittest
from threadpool import makeRequests,ThreadPool
from config import config
from tool.gernater import GernaterResult

if __name__ == '__main__':
    gr = GernaterResult()
    cases = unittest.defaultTestLoader.discover(config.BASE_PATH+"/testcase","test_*.py")
    print(cases)
    pool = ThreadPool(5)
    req_list = makeRequests(gr.run_case,cases)
    for req in req_list:
        print("=========req=========:",req)
        pool.putRequest(req)
    pool.wait()
    result = gr.combine_result()
    gr.runner.generateReport(cases,result)