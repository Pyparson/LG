import os
import unittest
from api.api_login import ApiLogin
from parameterized import parameterized
from tool.utils import load_excel_data
import time

base_path = os.path.dirname(__file__)
p = os.path.abspath(os.path.join(base_path, "..", "data","login.xls"))

class TestLogin(unittest.TestCase):
    def setUp(self):

        # p = os.path.abspath(os.path.join(base_path, "config.yaml"))
        # print(base_path)
        self.login_api = ApiLogin()

    # @parameterized.expand(load_excel_data('../data/login.xls'))
    @parameterized.expand(load_excel_data(os.path.abspath(os.path.join(base_path, "..", "data","login.xls"))))
    def test_login(self,case_name,phone,password,message,state):
        # time.sleep(2)
        params= {"phone": phone, "password": password}
        response = self.login_api.login(params)
        print(f"{case_name}  登陆的结果为：", response.json())
        self.assertEqual(message,response.json().get("message"))
        self.assertEqual(int(state), response.json().get("state"))


if __name__ == '__main__':
    base_path = os.path.dirname(__file__)
    # p = os.path.abspath(os.path.join(base_path, "config.yaml"))
    print(base_path)