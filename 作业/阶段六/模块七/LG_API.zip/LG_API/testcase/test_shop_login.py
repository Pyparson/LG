import os
import unittest

import requests
from parameterized import parameterized

from api.api_shop_login import LgShopLogin
from config.config import BASE_PATH
from tool.utils import load_excel_data
import time

base_path = os.path.dirname(__file__)
p = os.path.abspath(os.path.join(base_path, "..", "data","login.xls"))

os.path.abspath(os.path.join(BASE_PATH,  "data", "login_shop.xls"))

class TestShopLogin(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.login_api = LgShopLogin()

    def setUp(self):
        self.session = requests.Session()

    # @parameterized.expand(load_excel_data('../data/login.xls'))
    @parameterized.expand(load_excel_data(os.path.abspath(os.path.join(BASE_PATH,  "data", "login_shop.xls"))))
    def test_login(self,case_name,phone,password,verify_code,message,status):
        self.login_api.get_verify_session(self.session)
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        response = self.login_api.login(self.session,phone,password,verify_code,headers)
        print(f"{case_name}  登陆的结果为：", response.json())
        self.assertEqual(message,response.json().get("msg"))
        self.assertEqual(int(status), response.json().get("status"))


if __name__ == '__main__':
    base_path = os.path.dirname(__file__)
    # p = os.path.abspath(os.path.join(base_path, "config.yaml"))
    print(base_path)