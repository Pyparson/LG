import os
import unittest

import requests
from parameterized import parameterized

from api.api_shop_register import LgShopRegister
from config.config import BASE_PATH
from tool.logger import logger
from tool.utils import load_excel_data


class TestShopRegister(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.lgshop = LgShopRegister()

    def setUp(self):
        self.session = requests.Session()

    @parameterized.expand(load_excel_data(os.path.abspath(os.path.join(BASE_PATH,  "data", "register.xls"))))
    def test_register(self,case_name,phone,password,password2,verify_code,msg,stastus):
        self.lgshop.get_verify_session(self.session)
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        response = self.lgshop.register(self.session,phone,verify_code,password,password2,headers)
        # logger()
        print(f"{case_name}  注册的结果为：{response.json()}")
        self.assertEqual(msg, response.json().get("msg"))
        self.assertEqual(int(stastus), response.json().get("status"))