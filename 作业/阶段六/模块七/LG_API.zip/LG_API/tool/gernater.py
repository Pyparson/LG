import os
import sys

from config.config import BASE_PATH
from lib import HTMLTestRunner_PY3
base_path = os.path.dirname(__file__)

class GernaterResult:
    def __init__(self):
        report_path = os.path.abspath(os.path.join(BASE_PATH,  "report", "report2.html"))
        f = open(report_path,'wb')
        self.runner = HTMLTestRunner_PY3.HTMLTestRunner(f)
        self.result_list = []

    def run_case(self,testcase):
        result = self.runner.run(testcase)
        self.result_list.append(result)
        return result

    def combine_result(self):
        first_result = self.result_list[0]  # type:HTMLTestRunner_PY3._TestResult
        for i in range(1,len(self.result_list)):
            for temp in self.result_list[i].result:
                if temp[0]==0:
                    first_result.addSuccess(temp[1])           # 添加成功测试用例
                if temp[0]==1:
                    first_result.addFailure(temp[1],sys.exc_info())     # 添加失败测试用例
                if temp[0]==2:
                    first_result.addError(temp[1],sys.exc_info())       # 添加报错测试用例
        return first_result
