import logging
import os

from config.config import BASE_PATH


def logger():
    # 实例化日志器
    logger = logging.getLogger()
    # 设置日志等级
    logger.setLevel(logging.INFO)
    # 获取日志处理器
    # 控制台处理器
    sh = logging.StreamHandler()
    # 文件处理器 os.path.dirname(os.path.abspath(__file__)) 是获取当前utils.py的父级目录
    fh = logging.handlers.TimedRotatingFileHandler(os.path.abspath(os.path.join(BASE_PATH,  "logs", "test.log")),
                                                   when='h',
                                                   interval=24,
                                                   backupCount=3,
                                                   encoding="utf-8")
    # 设置日志格式
    fmt = "%(asctime)s [%(levelname)s] [%(funcName)s %(lineno)d] %(message)s"
    formatter = logging.Formatter(fmt)
    # 将格式添加到处理器
    sh.setFormatter(formatter)
    fh.setFormatter(formatter)
    # 将处理器添加到日志器
    logger.addHandler(sh)
    logger.addHandler(fh)
    # 返回日志器
    return logger