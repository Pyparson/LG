import hashlib

def lg_md5_encode(data):
    authcode = "TPSHOP"   # 认证code,每个系统都不一样
    new_data = authcode+data    # 认证code拼接密码组成要加密的数据
    md = hashlib.md5()
    md.update(new_data.encode(encoding='utf-8'))
    return md.hexdigest()

if __name__ == '__main__':
    print(lg_md5_encode('123456'))