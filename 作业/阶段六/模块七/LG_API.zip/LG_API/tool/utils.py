import json
import xml.etree.ElementTree as ET
import xlrd


def load_json_data(filename):
    with open(filename, 'r', encoding='utf-8') as f:
        jsonData = json.load(f)
        result_list = []
        for i in jsonData:
            # print(i)
            # print(tuple(i.values()))
            result_list.append(tuple(i.values()))
    return result_list


def load_xml_data(filename):
    with open(filename, encoding='utf-8') as f:
        tree = ET.parse(f)
        root = tree.getroot()  # 获取根节点
        result_list = []
        for case in root:  # 遍历root根节点下的所有子节点
            test_data = []
            for i in case:  # 遍历case节点下的所有子节点
                test_data.append(i.text)  # 读取子节点的值
            result_list.append(tuple(test_data))
    return result_list


def load_excel_data(filename):
    excel = xlrd.open_workbook(filename)     # 打开excel
    sheet = excel.sheet_by_index(0)          # 获取第一个sheet页
    # print(sheet)
    result_list = []
    for i in range(1, sheet.nrows):          # 从第一行遍历至最后一行有数据的行
        # print(sheet.row_values(i))
        result_list.append(tuple(sheet.row_values(i)))    # 获取某一行的数据并转换成tuple
    return result_list


if __name__ == '__main__':
    result = load_json_data('../data/login.json')
    print(result)
    print(load_xml_data('../data/login.xml'))
    print(load_excel_data('../data/login.xls'))
